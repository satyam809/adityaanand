<section class="about section" data-scroll-index="2">
               <div class="container">
                  <div class="row align-items-center">
                     <div class="col-md-12 col-lg-6">
                        <div class="about-image-pattern text-center">
                           <img src="img/bg/about_1.jpg" alt="About Image" class="img-fluid round-item">
                        </div>
                     </div>
                     <div class="col-md-12 col-lg-6">
                        <div class="about-inner">
                           <h4 class="about-title">
                              I'm <b>Aditya Anand</b><br>
                              <span>Social Worker And Founder Of The AAICO</span>
                           </h4>
                           <p class="about-text">
                              My journey began in the town of Bhagalpur in Bihar, Born on the 30th of April 1989 I am the 1st among the 4 children of Rita Devi and Upendra Prasad. Childhood was one of immense struggle and difficulty As a youngster I'm a business person and social work                                    
                           <ul class="about-list">
                              <li class="d-flex justify-content-between">
                                 <b>Name</b>
                                 <span>Aditya Anand</span>
                              </li>
                              <li class="d-flex justify-content-between">
                                 <b>Age</b>
                                 <span>31</span>
                              </li>
                              <li class="d-flex justify-content-between">
                                 <b>Email</b>
                                 <span>example@gmail.com</span>
                              </li>
                              <li class="d-flex justify-content-between">
                                 <b>Country</b>
                                 <span>India</span>
                              </li>
                              <li class="d-flex justify-content-between">
                                 <b>City</b>
                                 <span>Bhagalpur</span>
                              </li>
                              <li class="d-flex justify-content-between">
                                 <b>Address</b>
                                 <span>Bhagalpur, Bihar</span>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </section>