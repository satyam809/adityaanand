<section class="section my-team">
               <div class="container">
                  <div class="row align-items-center justify-content-center">
                     <div class="col-md-7">
                        <div class="section-heading">
                           <h2 class="section-title">My<span>Team</span></h2>
                           <p class="section-sub-title">
                              If you are going to use a passage of Lorem Ipsum, you need to 
                              be sure there isn't anything embarrassing hidden in the middle of text.
                           </p>
                        </div>
                     </div>
                  </div>
                  <div class="row justify-content-center">
                     <div class="col-md-6 col-sm-12 col-lg-4 team-card-resp">
                        <div class="team-card">
                           <div class="team-img-pattern">
                              <img src="img/team/team_image_01.png" class="img-fluid" alt="Team image">
                           </div>
                           <div class="team-body">
                              <h5>Jeremy Perkins</h5>
                              <span>Web Designer</span>
                              <div class="team-social">
                                 <a href="#0"><i class="fab fa-facebook-f"></i></a>
                                 <a href="#0"><i class="fab fa-twitter"></i></a>
                                 <a href="#0"><i class="fab fa-instagram"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6 col-sm-12 col-lg-4 team-card-resp">
                        <div class="team-card">
                           <div class="team-img-pattern">
                              <img src="img/team/team_image_02.png" class="img-fluid" alt="Team image">
                           </div>
                           <div class="team-body">
                              <h5>Adrian Boyd</h5>
                              <span>UI/UX Designer</span>
                              <div class="team-social">
                                 <a href="#0"><i class="fab fa-facebook-f"></i></a>
                                 <a href="#0"><i class="fab fa-twitter"></i></a>
                                 <a href="#0"><i class="fab fa-instagram"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6 col-sm-12 col-lg-4 team-card-resp">
                        <div class="team-card">
                           <div class="team-img-pattern">
                              <img src="img/team/team_image_03.png" class="img-fluid" alt="Team image">
                           </div>
                           <div class="team-body">
                              <h5>Alexander Doe</h5>
                              <span>Project Supervisor</span>
                              <div class="team-social">
                                 <a href="#0"><i class="fab fa-facebook-f"></i></a>
                                 <a href="#0"><i class="fab fa-twitter"></i></a>
                                 <a href="#0"><i class="fab fa-instagram"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>