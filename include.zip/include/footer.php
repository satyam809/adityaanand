<footer class="footer">
            <div class="footer-top">
               <div class="container">
                  <div class="row justify-content-center">
                     <div class="col-md-12">
                        <div class="footer-widget-box text-center">
                           
                           <ul class="footer-social">
                              <li>
                                 <a href="https://www.facebook.com/adityaanand.live/" class="footer-social-link" target="_blank">
                                 <i class="fab fa-facebook-f"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="https://www.instagram.com/adityaanand.live/?fbclid=IwAR0Fvf1BQBxhRUxxyPjb5-vHZrwWopFRYL4daibMz0RKCzSA-q92UzE0m_0" class="footer-social-link" target="_blank">
                                 <i class="fab fa-instagram"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="http://www.adityaanand.live" class="footer-social-link" target="_blank">
                                 <i class="fab fa-twitter"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="http://www.adityaanand.live" class="footer-social-link" target="_blank">
                                 <i class="fab fa-dribbble"></i>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <p class="copyright-text">Design By-</span> <a href="https://tiqto.com/" target="_blank">@TiQtO India an Innovaxy Techlabs India Pvt Ltd. All rights reserved.</a></p>
               </div>
            </div>
         </footer>