
<script src="js/jquery.js"></script>
<script src="js/typed.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>

<script>
   var options = {
       strings: ["Social Worker", "Social Worker"],
       typeSpeed: 40,
       backSpeed: 40,
       loop: true
   }
   var typed = new Typed("#typed-text", options);
</script>