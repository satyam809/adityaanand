<header class="header fixed-top">
            <div class="container">
               <nav class="navbar navbar-expand-lg p-0">
                  <a class="navbar-brand" href="index.html">
                  <img src="img/logo-anand.png" alt="Logo White" class="img-fluid logo-transparent">
                  <img src="img/logo-anand.png" alt="Logo White" class="img-fluid logo-normal">
                  </a>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#fixedNavbar" aria-controls="fixedNavbar" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="togler-icon-inner">
                  <span class="line-1"></span>
                  <span class="line-2"></span>
                  <span class="line-3"></span>
                  </span>
                  </button>
                  <div class="collapse navbar-collapse main-menu justify-content-end" id="fixedNavbar">
                     <ul class="navbar-nav">
                        <li class="nav-item">
                           <a class="nav-link active" href="#" data-scroll-nav="1">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#" data-scroll-nav="2">About</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#" data-scroll-nav="4">Images</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#" data-scroll-nav="3">Videos</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#" data-scroll-nav="7">Contact</a>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </header>