<footer class="main-footer">
    <strong>Design By-<a href="https://tiqto.com/">TiQtO India an Innovaxy Techlabs India Pvt Ltd.</a>.</strong> All rights
    reserved.
  </footer>
