<?php 
$conn=mysqli_connect('localhost','root','','adityaanand');
if (!$conn) {
	echo "Database is not connected";
}


?>